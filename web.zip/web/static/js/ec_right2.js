var ec_right2 = echarts.init(document.getElementById("r2"), "dark");

var datamessage = [];
var option_right2 = {
	title: {
		text: '出行选择线路',
		textStyle: {
			color: 'white'
		},
		left: 'left'
	},
    color: [
		"#006cff",
		"#60cda0",
		"#ed8884",
		"#ff9f7f",
		"#0096ff",
		"#9fe6b8",
		"#32c5e9",
		"#1d9dff"
	  ],
	  tooltip: {
		trigger: "item",
		formatter: "{a} <br/>{b} : {c} ({d}%)"
	  },
	  legend: {
		bottom: "0%",
		itemWidth: 10,
		itemHeight: 10,
		textStyle: {
		  color: "rgba(255,255,255,.5)",
		  fontSize: "12"
		}
	  },
	  series: [
		{
		  name: "地区分布",
		  type: "pie",
		  radius: ["10%", "70%"],
		  center: ["50%", "50%"],
		  roseType: "radius",
		  // 图形的文字标签
		  label: {
			fontSize: 10
		  },
		  // 链接图形和文字的线条
		  labelLine: {
			// length 链接图形的线条
			length: 6,
			// length2 链接文字的线条
			length2: 8
		  },
		  data: [
			{ value: 216325, name: "A线路" },
			{ value: 1677014, name: "B线路" },
			{ value: 646253, name: "C线路" },
		  ]
		}
	  ]
};
//使用制定的配置项和数据显示图表
ec_right2.setOption(option_right2);
