//初始化echarts实例
var ec_center = echarts.init(document.getElementById("c2"),"dark");
var option_1 = {
    tooltip: {
		trigger: "axis"
	  },
	  legend: {
		top: "0%",
		//data: ["邮件营销", "联盟广告", "视频广告", "直接访问", "搜索引擎"],
		textStyle: {
		  color: "rgba(255,255,255,.5)",
		  fontSize: "12"
		}
	  },
  
	  grid: {
		left: "10",
		top: "30",
		right: "10",
		bottom: "10",
		containLabel: true
	  },
	  xAxis: [
		{
		  type: "category",
		  boundaryGap: false,
		  // x轴更换数据
		  data: [
			"day1",
			"day2",
			"day3",
			"day4",
			"day5",
			"day6",
			"day7",
			"day8",
			"day9",
			"day10",
			"day11",
			"day12",
			"day13",
			"day14"
		  ],
		  // 文本颜色为rgba(255,255,255,.6)  文字大小为 12
		  axisLabel: {
			textStyle: {
			  color: "rgba(255,255,255,.6)",
			  fontSize: 12
			}
		  },
		  // x轴线的颜色为   rgba(255,255,255,.2)
		  axisLine: {
			lineStyle: {
			  color: "rgba(255,255,255,.2)"
			}
		  }
		}
	  ],
	  yAxis: [
		{
		  type: "value",
		  axisTick: { show: false },
		  axisLine: {
			lineStyle: {
			  color: "rgba(255,255,255,.1)"
			}
		  },
		  axisLabel: {
			textStyle: {
			  color: "rgba(255,255,255,.6)",
			  fontSize: 12
			}
		  },
		  // 修改分割线的颜色
		  splitLine: {
			lineStyle: {
			  color: "rgba(255,255,255,.1)"
			}
		  }
		}
	  ],
	  series: [
		{
		  name: "C线路",
		  type: "line",
		  smooth: true,
		  // 单独修改当前线条的样式
		  lineStyle: {
			color: "#0184d5",
			width: "2"
		  },
		  // 填充颜色设置
		  areaStyle: {
			color: new echarts.graphic.LinearGradient(
			  0,
			  0,
			  0,
			  1,
			  [
				{
				  offset: 0,
				  color: "rgba(1, 132, 213, 0.4)" // 渐变色的起始颜色
				},
				{
				  offset: 0.8,
				  color: "rgba(1, 132, 213, 0.1)" // 渐变线的结束颜色
				}
			  ],
			  false
			),
			shadowColor: "rgba(0, 0, 0, 0.1)"
		  },
		  // 设置拐点
		  symbol: "circle",
		  // 拐点大小
		  symbolSize: 8,
		  // 开始不显示拐点， 鼠标经过显示
		  showSymbol: false,
		  // 设置拐点颜色以及边框
		  itemStyle: {
			color: "#0184d5",
			borderColor: "rgba(221, 220, 107, .1)",
			borderWidth: 12
		  },
		  data: [
			301332,
			340254,
			304354,
			400000,
			354420,
			443330,
			343430,
			483430,
			325330,
			428680,
			386330,
			487860,
			378860,
			476780
		  ]
		},
		{
		  name: "B线路",
		  type: "line",
		  smooth: true,
		  lineStyle: {
			normal: {
			  color: "#00d887",
			  width: 2
			}
		  },
		  areaStyle: {
			normal: {
			  color: new echarts.graphic.LinearGradient(
				0,
				0,
				0,
				1,
				[
				  {
					offset: 0,
					color: "rgba(0, 216, 135, 0.4)"
				  },
				  {
					offset: 0.8,
					color: "rgba(0, 216, 135, 0.1)"
				  }
				],
				false
			  ),
			  shadowColor: "rgba(0, 0, 0, 0.1)"
			}
		  },
		  // 设置拐点 小圆点
		  symbol: "circle",
		  // 拐点大小
		  symbolSize: 5,
		  // 设置拐点颜色以及边框
		  itemStyle: {
			color: "#00d887",
			borderColor: "rgba(221, 220, 107, .1)",
			borderWidth: 12
		  },
		  // 开始不显示拐点， 鼠标经过显示
		  showSymbol: true,
		  data: [
			1302002,
			1657534,
			2025577,
			1502152,
			2105414,
			2230251,
			2254811,
			1602454,
			1452558,
			1625455,
			2252544,
			2325458,
			1651451,
			1687844
		  ]
		}
	  ]
	// color: ['#00EE00', '#FF9F7F', '#FFD700']
};

//使用制定的配置项和数据显示图表
ec_center.setOption(option_1);
