var ec_left2 = echarts.init(document.getElementById("l2"),"dark");

var option_left2 = {

	title: {
		text: '各站点出站人数排行'
	  },
	  tooltip: {
		  
		trigger: 'axis',
		axisPointer: {
			type: 'shadow'
		}
		// trigger: 'axis',
		// axisPointer: {
		//   type: 'shadow'
		// }
	  },
	  //legend: {},
	  grid: {
		left: '3%',
		right: '4%',
		bottom: '3%',
		containLabel: true
	  },
	  xAxis: {
		//show:false,
		type: 'value',
		
		boundaryGap: [0, 0.01]
	  },
	  yAxis: {
		type: 'category',
		data: ['10号站点', '7号站点', '4号站点', '9号站点', '15号站点'],
		show:true
	  },
	  series: [
		{
		  type: 'bar',
		  data: [],
		  barMaxWidth: "50%"
		},
	  ]};
	  
ec_left2.setOption(option_left2);
