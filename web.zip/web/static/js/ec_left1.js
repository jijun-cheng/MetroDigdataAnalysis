var ec_left1 = echarts.init(document.getElementById("l1"),"dark");

var option_left1 = {

	title: {
		text: '各站点入栈人数排行'
	  },
	  tooltip: {
		  
		trigger: 'axis',
		axisPointer: {
			type: 'shadow'
		}
		// trigger: 'axis',
		// axisPointer: {
		//   type: 'shadow'
		// }
	  },
	  //legend: {},
	  grid: {
		left: '3%',
		right: '4%',
		bottom: '3%',
		containLabel: true
	  },
	  xAxis: {
		//show:false,
		type: 'value',
		data: [],
		boundaryGap: [0, 0.01]
	  },
	  yAxis: {
		type: 'category',
		data: ['10号站点', '7号站点', '4号站点', '9号站点', '15号站点'],
		show:true
	  },
	  series: [
		{
		  type: 'bar',
		  data: [],
		  barMaxWidth: "50%"
		},
	  ]
      };
	  
ec_left1.setOption(option_left1);
// window.addEventListener("resize", function() {
//     ec_left1.resize();
//   });
